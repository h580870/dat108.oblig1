package no.hvl.dat108;

import java.util.Scanner;

public class StartDaGame {
	
	public static void main (String[] args) {
		//While loop gives user the option to start new game by pressing 1.
		//When user chooses, he can end the game, simply by pressing 2.
		
		boolean exit = false;
		
		while(!exit) {
			printMenu();
			int option = scanOptions();
			
			if (option == 1)
				startNewGame();
			else
				exit = true;
		}
		
	}
	
	public static void startNewGame() {
		Game game = new Game();
		game.startGame();
	}
	
	public static void printMenu() {
		//Here we print the option the user is given.
		System.out.println("Start Game? Press 1 and press enter.");
		System.out.println("Exit? Press 2 and press enter.");
	}
	
	public static int scanOptions() {
		//Here we scan whatever the user chooses to do.
		Scanner scan = new Scanner(System.in);
		int option = scan.nextInt();
		//scan.close();
		return option;
	}
	
}
