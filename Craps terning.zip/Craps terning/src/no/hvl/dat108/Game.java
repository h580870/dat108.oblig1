package no.hvl.dat108;

public class Game {
	
	public Game() {
		
	}
	
	public void startGame() {
		//Here we create a game with dice.
		Die die1 = new Die();
		Die die2 = new Die();
		//And then we throw the dice.
		int dieNumber1 = die1.throwDie();
		int dieNumber2 = die2.throwDie();
		
		
		//Now, lets add up the numbers, and see how much we got.
		int diceValue = dieNumber1 + dieNumber2;
		
		//Then we check whether the use wins or loses.
		if (diceValue == 7) {
			System.out.println("Dice 1: " + dieNumber1 + " Dice 2: " + dieNumber2);
			System.out.println("Yay, you won! You got a total of " + diceValue + "!");
		} else if (diceValue == 6) {
			System.out.println("Dice 1: " + dieNumber1 + " Dice 2: " + dieNumber2);
			System.out.println("BBC news: Man died after a person accedently threw dices in his throat.");
		} else {
			System.out.println("Dice 1: " + dieNumber1 + " Dice 2: " + dieNumber2);
			System.out.println("No win I'm afraid! You got a total of " + diceValue + ".");
		}
		die1.kastPaaPerson();
	}
}
