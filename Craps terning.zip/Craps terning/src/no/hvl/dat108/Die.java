package no.hvl.dat108;

import java.util.Random;

public class Die {
	
	public int throwDie() {
		Random random = new Random();
		return 1+random.nextInt(5);
		
	}
	
	public void kastPaaPerson() {
		System.out.println("\nRandom person: \"Ouch! Don't throw the dice on me!\"\n");
	}
}
