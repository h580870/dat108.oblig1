package no.hvl.dat108;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class Tester {

	@Test
	void diceThrow() {
		Die dice = new Die();
		int diceThrow = dice.throwDie();
		
		boolean legalDiceThrow = false;
		
		for (int i = 1; i <= 6; i++) {
			if (i == diceThrow) {
				legalDiceThrow = true;
			}
		}
		assertTrue(true);
	}

}
